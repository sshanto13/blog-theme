

  <div class="wow zoomIn col-xs-12 col-sm-12 col-md-4 "> <!-- col-xs-12 col-sm-12 col-md-4  -->
          <div class="sidebar">
            <div class="list-group">
              <a href="#" class="list-group-item active">
                categories
              </a>
              <a href="#" class="list-group-item">Web Design <span class="pull-right">(14)</span></a>
              <a href="#" class="list-group-item">Illustration <span class="pull-right">(14)</span></a>
              <a href="#" class="list-group-item">HTML5 & CSS3 <span class="pull-right">(14)</span></a>
              <a href="#" class="list-group-item">Bootstrap <span class="pull-right">(14)</span></a>
            </div><!-- /.list-group -->
          </div><!-- sidebar -->
          <div class="blog-sidebar sidebar">
            <div class="sidebar-heading">
              recent posts
            </div>
            <div class="media"><!-- media -->
              <div class="media-left"><!-- media-left -->
                <a href="#">
                  <img class="media-object" src="img/thumb-01.jpg" alt="thumb-01">
                </a>
              </div><!-- /.media-left -->
              <div class="media-body"><!-- media-body -->
                <h3 class="media-heading"><a href="#">Agna est ullamcorper</a></h3>
                <p>December 31, 2014</p>
                <a href="#"><span>0 Conmments</span></a>
              </div><!-- /.media-body -->
            </div> <!-- /.media -->

            <div class="media"> <!-- media -->
              <div class="media-left">
                <a href="#">
                  <img class="media-object" src="img/thumb-02.jpg" alt="thumb-02">
                </a>
              </div><!-- media-left -->
              <div class="media-body">
                <h3 class="media-heading"><a href="#">Agna est ullamcorper</a></h3>
                <p>December 31, 2014</p>
                <a href="#"><span>0 Conmments</span></a>
              </div><!-- media-body -->
            </div> <!-- /.media -->


            <div class="media">
              <div class="media-left">
                <a href="#">
                  <img class="media-object" src="img/thumb-03.jpg" alt="thumb-03">
                </a>
              </div><!-- media-left -->
              <div class="media-body">
                <h3 class="media-heading"><a href="#">Agna est ullamcorper</a></h3>
                <p>December 31, 2014</p>
                <a href="#"><span>0 Conmments</span></a>
              </div><!-- media-body -->
            </div><!-- /.media -->


          </div><!-- blog-sidebar -->

          <div class="blog-sidebar sidebar">
            <div class="sidebar-heading">
              tags
            </div>
            <ul>
              <li><a href="#">logo</a></li>
              <li><a href="#">html</a></li>
              <li><a href="#">design</a></li>
              <li><a href="#">bootstrap</a></li>
              <li><a href="#">css</a></li>
              <li><a href="#">development</a></li>
            </ul>
          </div><!-- blog-sidebar -->
</div>
